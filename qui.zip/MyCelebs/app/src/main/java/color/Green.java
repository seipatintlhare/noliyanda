package color;

public class Green {
}
