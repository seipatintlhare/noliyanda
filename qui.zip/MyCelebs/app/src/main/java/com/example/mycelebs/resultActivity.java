package com.example.mycelebs;

public class resultActivity {
}
