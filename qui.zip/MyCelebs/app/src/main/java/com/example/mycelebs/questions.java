package com.example.mycelebs;

public class questions {

    public String mQuestions[] ={
            "what is the name of the above beautiful celeb?",
            "what is the name of the  beloved celeb?",
            "what is the name of the above beloved celeb?"
    } ;
    public class Images{

        public int [] pictures = {
                R.drawable.bbeee, R.drawable.cool, R.drawable.tati

    };

    private String mChoices[][] ={
            {"Bebe Rexha","Ms Seipati","Puseletso"},
            {"Nasty","Bebe Lesole","Bebe Cool"},
            {"Bebe Rexha"," Seipati","Tatiana"}
    };
    private String images[][]={
            {"bbeee"},
            {"cool"},
            {"tati"}
    };

    private String mCorrectAnswers[] = {"Bebe Rexha","Bebe Cool","Tatiana"};

    public String getQuestion(int a){
        String question = mQuestions[a];
        return question;
        
    }
    public String getChoice1(int a) {
        String choice = mChoices[a][0];
        return choice;
    }
    public String getChoice2(int a) {
        String choice = mChoices[a][1];
        return choice;
    }
    public String getChoice3(int a) {
        String choice = mChoices[a][2];
        return choice;
    }

    public String getCorrectAnswers(int a) {
        String answer = mCorrectAnswers[a];
        return answer;

    }
}
